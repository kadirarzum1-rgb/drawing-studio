package com.example.drawing_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
