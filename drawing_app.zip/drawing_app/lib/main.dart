import 'package:flutter/material.dart';
import 'app/app.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // TODO: Firebase'i başlat
  // await Firebase.initializeApp(
  //   options: DefaultFirebaseOptions.currentPlatform,
  // );
  
  // TODO: Hive'ı başlat (yerel veritabanı için)
  // await Hive.initFlutter();
  
  runApp(const StudyDrawApp());
}
