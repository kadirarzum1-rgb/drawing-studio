import 'package:flutter/material.dart';
import 'dart:ui' as ui;

import '../../../../core/theme/app_theme.dart';

class CanvasPanel extends StatefulWidget {
  final String currentTool;
  final Color currentColor;
  final double currentSize;
  final String currentTemplate;

  const CanvasPanel({
    super.key,
    required this.currentTool,
    required this.currentColor,
    required this.currentSize,
    required this.currentTemplate,
  });

  @override
  State<CanvasPanel> createState() => _CanvasPanelState();
}

class _CanvasPanelState extends State<CanvasPanel> {
  final List<DrawnLine> lines = <DrawnLine>[];
  final List<List<DrawnLine>> undoHistory = [];
  int historyIndex = -1;

  void _onPanStart(DragStartDetails details) {
    final box = context.findRenderObject() as RenderBox;
    final point = box.globalToLocal(details.globalPosition);
    
    // Save state for undo
    _saveState();
    
    setState(() {
      if (widget.currentTool == 'eraser') {
        // For eraser, create a special line that will remove content
        lines.add(
          DrawnLine(
            path: Path()..moveTo(point.dx, point.dy),
            color: Colors.transparent,
            width: widget.currentSize,
            tool: widget.currentTool,
            isEraser: true,
          ),
        );
      } else {
        lines.add(
          DrawnLine(
            path: Path()..moveTo(point.dx, point.dy),
            color: widget.currentColor,
            width: widget.currentSize,
            tool: widget.currentTool,
          ),
        );
      }
    });
  }

  void _onPanUpdate(DragUpdateDetails details) {
    final box = context.findRenderObject() as RenderBox;
    final point = box.globalToLocal(details.globalPosition);
    
    setState(() {
      if (lines.isNotEmpty) {
        lines.last.path.lineTo(point.dx, point.dy);
      }
    });
  }

  void _saveState() {
    historyIndex++;
    if (historyIndex < undoHistory.length) {
      undoHistory.removeRange(historyIndex, undoHistory.length);
    }
    undoHistory.add(List<DrawnLine>.from(lines));
    
    // Limit history size
    if (undoHistory.length > 50) {
      undoHistory.removeAt(0);
      historyIndex--;
    }
  }

  void _undo() {
    if (historyIndex > 0) {
      historyIndex--;
      setState(() {
        lines.clear();
        lines.addAll(List<DrawnLine>.from(undoHistory[historyIndex]));
      });
    }
  }

  void _redo() {
    if (historyIndex < undoHistory.length - 1) {
      historyIndex++;
      setState(() {
        lines.clear();
        lines.addAll(List<DrawnLine>.from(undoHistory[historyIndex]));
      });
    }
  }

  void _clear() {
    _saveState();
    setState(() {
      lines.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppTheme.bgPrimary,
      child: Column(
        children: [
          // Canvas Toolbar
          Container(
            height: 50,
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border(
                bottom: BorderSide(
                  color: AppTheme.borderPrimary,
                  width: 1,
                ),
              ),
            ),
            child: Row(
              children: [
                // Left toolbar buttons
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  child: Row(
                    children: [
                      _buildToolbarButton(
                        icon: Icons.undo,
                        tooltip: 'Geri Al',
                        onPressed: historyIndex > 0 ? _undo : null,
                      ),
                      const SizedBox(width: 5),
                      _buildToolbarButton(
                        icon: Icons.redo,
                        tooltip: 'İleri Al',
                        onPressed: historyIndex < undoHistory.length - 1 ? _redo : null,
                      ),
                      const SizedBox(width: 5),
                      _buildToolbarButton(
                        icon: Icons.clear,
                        tooltip: 'Temizle',
                        onPressed: lines.isNotEmpty ? _clear : null,
                      ),
                    ],
                  ),
                ),
                
                const Spacer(),
                
                // Right toolbar buttons
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  child: Row(
                    children: [
                      _buildToolbarButton(
                        icon: Icons.download,
                        tooltip: 'Resim Olarak Kaydet',
                        onPressed: () {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Resim kaydedildi!')),
                          );
                        },
                      ),
                      const SizedBox(width: 5),
                      _buildToolbarButton(
                        icon: Icons.print,
                        tooltip: 'Yazdır',
                        onPressed: () {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Yazdırma başlatıldı!')),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          
          // Canvas Area
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(20),
              child: Center(
                child: Container(
                  width: 800,
                  height: 600,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: AppTheme.borderPrimary,
                      width: 2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.4),
                        blurRadius: 25,
                        offset: const Offset(0, 8),
                      ),
                    ],
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: GestureDetector(
                      onPanStart: _onPanStart,
                      onPanUpdate: _onPanUpdate,
                      child: CustomPaint(
                        painter: DrawingPainter(lines: lines, template: widget.currentTemplate),
                        size: const Size(800, 600),
                        child: Container(
                          width: 800,
                          height: 600,
                          color: Colors.transparent,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildToolbarButton({
    required IconData icon,
    required String tooltip,
    required VoidCallback? onPressed,
  }) {
    return Tooltip(
      message: tooltip,
      child: IconButton(
        onPressed: onPressed,
        icon: Icon(icon),
        color: onPressed != null ? AppTheme.textMuted : AppTheme.borderPrimary,
        style: IconButton.styleFrom(
          backgroundColor: AppTheme.bgCard,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
            side: BorderSide(
              color: AppTheme.borderPrimary,
              width: 1,
            ),
          ),
        ),
      ),
    );
  }
}

class DrawnLine {
  final Path path;
  final Color color;
  final double width;
  final String tool;
  final bool isEraser;

  DrawnLine({
    required this.path,
    required this.color,
    required this.width,
    required this.tool,
    this.isEraser = false,
  });
}

class DrawingPainter extends CustomPainter {
  final List<DrawnLine> lines;
  final String template;

  DrawingPainter({
    required this.lines,
    required this.template,
  });

  @override
  void paint(Canvas canvas, Size size) {
    // Draw white background first
    final backgroundPaint = Paint()..color = Colors.white;
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), backgroundPaint);
    
    // Draw template background
    _drawTemplate(canvas, size);
    
    // Create a separate layer for drawing content
    final recorder = ui.PictureRecorder();
    final drawingCanvas = Canvas(recorder);
    
    // Draw all lines on the drawing layer
    for (final line in lines) {
      if (line.isEraser) {
        // For eraser, use destination-out blend mode
        final paint = Paint()
          ..blendMode = BlendMode.clear
          ..strokeWidth = line.width
          ..strokeCap = StrokeCap.round
          ..strokeJoin = StrokeJoin.round
          ..style = PaintingStyle.stroke;
        
        drawingCanvas.drawPath(line.path, paint);
      } else {
        final paint = Paint()
          ..color = line.color
          ..strokeWidth = line.width
          ..strokeCap = StrokeCap.round
          ..strokeJoin = StrokeJoin.round
          ..style = PaintingStyle.stroke;

        // Apply different effects based on tool
        switch (line.tool) {
          case 'brush':
            paint.strokeCap = StrokeCap.round;
            paint.color = line.color.withOpacity(0.8);
            break;
          case 'marker':
            paint.color = line.color.withOpacity(0.4);
            paint.strokeCap = StrokeCap.square;
            paint.strokeWidth = line.width * 2;
            break;
          case 'pencil':
            paint.color = line.color.withOpacity(0.7);
            break;
          default: // pen
            break;
        }

        drawingCanvas.drawPath(line.path, paint);
      }
    }
    
    // Convert the drawing to a picture and draw it on main canvas
    final picture = recorder.endRecording();
    canvas.drawPicture(picture);
  }

  void _drawTemplate(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFFE0E0E0).withOpacity(0.5)
      ..strokeWidth = 1;

    switch (template) {
      case 'Çizgili Kağıt':
        const spacing = 30.0;
        for (double y = spacing; y < size.height; y += spacing) {
          canvas.drawLine(
            Offset(0, y),
            Offset(size.width, y),
            paint,
          );
        }
        
        // Left margin
        final marginPaint = Paint()
          ..color = Colors.red.withOpacity(0.3)
          ..strokeWidth = 2;
        canvas.drawLine(
          const Offset(60, 0),
          Offset(60, size.height),
          marginPaint,
        );
        break;
        
      case 'Kare Kağıt':
        const spacing = 20.0;
        for (double x = spacing; x < size.width; x += spacing) {
          canvas.drawLine(
            Offset(x, 0),
            Offset(x, size.height),
            paint,
          );
        }
        for (double y = spacing; y < size.height; y += spacing) {
          canvas.drawLine(
            Offset(0, y),
            Offset(size.width, y),
            paint,
          );
        }
        break;
        
      case 'Noktalı Kağıt':
        const spacing = 20.0;
        final dotPaint = Paint()
          ..color = const Color(0xFFE0E0E0)
          ..style = PaintingStyle.fill;
        
        for (double x = spacing; x < size.width; x += spacing) {
          for (double y = spacing; y < size.height; y += spacing) {
            canvas.drawCircle(Offset(x, y), 1, dotPaint);
          }
        }
        break;
        
      case 'Müzik Kağıdı':
        const lineSpacing = 15.0;
        const staffSpacing = 100.0;
        
        for (double staffY = 50; staffY < size.height - 50; staffY += staffSpacing) {
          for (int line = 0; line < 5; line++) {
            final y = staffY + (line * lineSpacing);
            canvas.drawLine(
              Offset(20, y),
              Offset(size.width - 20, y),
              paint,
            );
          }
        }
        break;
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
