import 'package:flutter/material.dart';

import '../../../../core/theme/app_theme.dart';

class AppHeader extends StatelessWidget {
  final String currentTool;
  final double currentSize;
  final Color currentColor;
  final bool isStudyModeActive;
  final VoidCallback onToggleStudyMode;
  final VoidCallback onSaveProject;

  const AppHeader({
    super.key,
    required this.currentTool,
    required this.currentSize,
    required this.currentColor,
    required this.isStudyModeActive,
    required this.onToggleStudyMode,
    required this.onSaveProject,
  });

  String getToolDisplayName(String tool) {
    const toolNames = {
      'pen': 'Tükenmez Kalem',
      'brush': 'Boyama Fırçası',
      'pencil': 'Kurşun Kalem',
      'marker': 'Fosforlu Kalem',
      'eraser': 'Silgi',
      'text': 'Metin Aracı',
      'line': 'Düz Çizgi',
      'rectangle': 'Dikdörtgen',
      'circle': 'Daire',
      'triangle': 'Üçgen',
      'arrow': 'Ok',
      'star': 'Yıldız'
    };
    return toolNames[tool] ?? tool;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 70,
      decoration: BoxDecoration(
        color: AppTheme.bgSecondary,
        border: Border(
          bottom: BorderSide(
            color: AppTheme.borderPrimary,
            width: 1,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 15,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24),
        child: Row(
          children: [
            // Left - App Logo
            Expanded(
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [
                          AppTheme.primaryColor,
                          AppTheme.primaryDarkColor,
                        ],
                      ),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Icon(
                      Icons.school,
                      color: AppTheme.textPrimary,
                      size: 24,
                    ),
                  ),
                  const SizedBox(width: 12),
                  ShaderMask(
                    shaderCallback: (bounds) => const LinearGradient(
                      colors: [
                        AppTheme.primaryColor,
                        AppTheme.primaryDarkColor,
                      ],
                    ).createShader(bounds),
                    child: const Text(
                      'StudyDraw',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            
            // Center - Tool Status
            Expanded(
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 24,
                  vertical: 10,
                ),
                decoration: BoxDecoration(
                  color: AppTheme.bgCard,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: AppTheme.borderPrimary,
                    width: 1,
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      getToolDisplayName(currentTool),
                      style: const TextStyle(
                        color: AppTheme.textSecondary,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const Text(
                      ' | ',
                      style: TextStyle(
                        color: AppTheme.borderSecondary,
                        fontWeight: FontWeight.w300,
                      ),
                    ),
                    Text(
                      '${currentSize.toInt()}px',
                      style: const TextStyle(
                        color: AppTheme.textSecondary,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    const Text(
                      ' | ',
                      style: TextStyle(
                        color: AppTheme.borderSecondary,
                        fontWeight: FontWeight.w300,
                      ),
                    ),
                    Container(
                      width: 24,
                      height: 24,
                      decoration: BoxDecoration(
                        color: currentColor,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: AppTheme.borderPrimary,
                          width: 2,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.3),
                            blurRadius: 8,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            
            // Right - Action buttons
            Expanded(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  _buildHeaderButton(
                    onPressed: onToggleStudyMode,
                    icon: isStudyModeActive 
                        ? Icons.pause 
                        : Icons.book_outlined,
                    label: isStudyModeActive 
                        ? 'Normal Mod' 
                        : 'Çalışma Modu',
                    isActive: isStudyModeActive,
                    isSecondary: true,
                  ),
                  const SizedBox(width: 12),
                  _buildHeaderButton(
                    onPressed: onSaveProject,
                    icon: Icons.save,
                    label: 'Kaydet',
                    isActive: false,
                    isSecondary: false,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeaderButton({
    required VoidCallback onPressed,
    required IconData icon,
    required String label,
    required bool isActive,
    required bool isSecondary,
  }) {
    return ElevatedButton.icon(
      onPressed: onPressed,
      icon: Icon(icon, size: 18),
      label: Text(
        label,
        style: const TextStyle(
          fontWeight: FontWeight.w600,
          fontSize: 14,
        ),
      ),
      style: ElevatedButton.styleFrom(
        backgroundColor: isActive
            ? (isSecondary ? AppTheme.secondaryColor : AppTheme.primaryColor)
            : (isSecondary ? AppTheme.bgCard : AppTheme.primaryColor),
        foregroundColor: AppTheme.textPrimary,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
          side: isSecondary && !isActive
              ? const BorderSide(color: AppTheme.borderPrimary)
              : BorderSide.none,
        ),
        elevation: isSecondary && !isActive ? 0 : 4,
      ),
    );
  }
}
