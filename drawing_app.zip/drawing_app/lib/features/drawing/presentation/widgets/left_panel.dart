import 'package:flutter/material.dart';

import '../../../../core/theme/app_theme.dart';

class LeftPanel extends StatelessWidget {
  final String currentTool;
  final Color currentColor;
  final double currentSize;
  final String currentTemplate;
  final String currentFont;
  final double currentFontSize;
  final Map<String, bool> textStyles;
  final Function(String) onToolChanged;
  final Function(Color) onColorChanged;
  final Function(double) onSizeChanged;
  final Function(String) onTemplateChanged;
  final Function(String) onFontChanged;
  final Function(double) onFontSizeChanged;
  final Function(String, bool) onTextStyleChanged;

  const LeftPanel({
    super.key,
    required this.currentTool,
    required this.currentColor,
    required this.currentSize,
    required this.currentTemplate,
    required this.currentFont,
    required this.currentFontSize,
    required this.textStyles,
    required this.onToolChanged,
    required this.onColorChanged,
    required this.onSizeChanged,
    required this.onTemplateChanged,
    required this.onFontChanged,
    required this.onFontSizeChanged,
    required this.onTextStyleChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 320,
      decoration: BoxDecoration(
        color: AppTheme.bgSecondary,
        border: Border(
          right: BorderSide(
            color: AppTheme.borderPrimary,
            width: 1,
          ),
        ),
      ),
      child: Column(
        children: [
          // Header
          Container(
            padding: const EdgeInsets.all(20),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [AppTheme.primaryColor, AppTheme.primaryDarkColor],
              ),
            ),
            child: const Row(
              children: [
                Icon(Icons.brush, color: AppTheme.textPrimary, size: 20),
                SizedBox(width: 10),
                Text(
                  'Çizim Araçları',
                  style: TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          
          // Scrollable content
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(0),
              children: [
                _buildToolsSection(),
                _buildShapesSection(),
                _buildSizeSection(),
                _buildColorSection(),
                _buildTemplateSection(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildToolsSection() {
    final tools = [
      {'id': 'pen', 'icon': Icons.edit, 'label': 'Tükenmez'},
      {'id': 'brush', 'icon': Icons.brush, 'label': 'Boyama'},
      {'id': 'pencil', 'icon': Icons.create, 'label': 'Kurşun'},
      {'id': 'marker', 'icon': Icons.highlight, 'label': 'Marker'},
      {'id': 'eraser', 'icon': Icons.cleaning_services, 'label': 'Silgi'},
      {'id': 'text', 'icon': Icons.text_fields, 'label': 'Metin'},
    ];

    return _buildSection(
      'Araçlar',
      child: GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 1.2,
        ),
        itemCount: tools.length,
        itemBuilder: (context, index) {
          final tool = tools[index];
          final isActive = currentTool == tool['id'];
          
          return GestureDetector(
            onTap: () => onToolChanged(tool['id'] as String),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              decoration: BoxDecoration(
                color: isActive ? AppTheme.primaryColor : AppTheme.bgCard,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isActive ? AppTheme.primaryColor : AppTheme.borderPrimary,
                  width: 2,
                ),
                boxShadow: isActive ? [
                  BoxShadow(
                    color: AppTheme.primaryColor.withOpacity(0.3),
                    blurRadius: 8,
                    offset: const Offset(0, 4),
                  ),
                ] : null,
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    tool['icon'] as IconData,
                    size: 24,
                    color: isActive ? AppTheme.textPrimary : AppTheme.textSecondary,
                  ),
                  const SizedBox(height: 6),
                  Text(
                    tool['label'] as String,
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: isActive ? AppTheme.textPrimary : AppTheme.textSecondary,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildShapesSection() {
    final shapes = [
      {'id': 'line', 'icon': Icons.remove},
      {'id': 'rectangle', 'icon': Icons.rectangle_outlined},
      {'id': 'circle', 'icon': Icons.circle_outlined},
      {'id': 'triangle', 'icon': Icons.change_history},
      {'id': 'arrow', 'icon': Icons.arrow_right_alt},
      {'id': 'star', 'icon': Icons.star_outline},
    ];

    return _buildSection(
      'Şekiller',
      child: GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 3,
          crossAxisSpacing: 8,
          mainAxisSpacing: 8,
          childAspectRatio: 1,
        ),
        itemCount: shapes.length,
        itemBuilder: (context, index) {
          final shape = shapes[index];
          final isActive = currentTool == shape['id'];
          
          return GestureDetector(
            onTap: () => onToolChanged(shape['id'] as String),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              decoration: BoxDecoration(
                color: isActive ? AppTheme.accentColor : AppTheme.bgCard,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: isActive ? AppTheme.accentColor : AppTheme.borderPrimary,
                  width: 2,
                ),
                boxShadow: isActive ? [
                  BoxShadow(
                    color: AppTheme.accentColor.withOpacity(0.3),
                    blurRadius: 8,
                    offset: const Offset(0, 4),
                  ),
                ] : null,
              ),
              child: Icon(
                shape['icon'] as IconData,
                size: 20,
                color: isActive ? AppTheme.textPrimary : AppTheme.textSecondary,
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildSizeSection() {
    return _buildSection(
      'Fırça Boyutu',
      child: Column(
        children: [
          Slider(
            value: currentSize,
            min: 1,
            max: 100,
            divisions: 99,
            activeColor: AppTheme.primaryColor,
            inactiveColor: AppTheme.borderPrimary,
            onChanged: onSizeChanged,
          ),
          const SizedBox(height: 10),
          Container(
            height: 60,
            decoration: BoxDecoration(
              color: AppTheme.bgCard,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppTheme.borderPrimary),
            ),
            child: Center(
              child: Container(
                width: (currentSize / 2).clamp(5, 50),
                height: (currentSize / 2).clamp(5, 50),
                decoration: BoxDecoration(
                  color: AppTheme.textPrimary,
                  borderRadius: BorderRadius.circular(50),
                  border: Border.all(color: AppTheme.borderSecondary),
                ),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            '${currentSize.toInt()}px',
            style: const TextStyle(
              color: AppTheme.primaryColor,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildColorSection() {
    final colors = [
      [Colors.black, Colors.red, Colors.green, Colors.blue],
      [Colors.yellow, Colors.purple, Colors.cyan, Colors.orange],
      [const Color(0xFF800080), Colors.pink, Colors.brown, Colors.grey],
      [Colors.white, const Color(0xFF90EE90), const Color(0xFF87CEEB), const Color(0xFFDDA0DD)],
    ];

    return _buildSection(
      'Renk Paleti',
      child: Column(
        children: [
          ...colors.map((colorRow) => Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Row(
              children: colorRow.map((color) => Expanded(
                child: GestureDetector(
                  onTap: () => onColorChanged(color),
                  child: Container(
                    height: 40,
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    decoration: BoxDecoration(
                      color: color,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: currentColor == color 
                            ? AppTheme.textPrimary 
                            : (color == Colors.white ? AppTheme.borderPrimary : Colors.transparent),
                        width: currentColor == color ? 3 : (color == Colors.white ? 2 : 0),
                      ),
                    ),
                  ),
                ),
              )).toList(),
            ),
          )),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppTheme.bgCard,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppTheme.borderPrimary),
            ),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 30,
                  decoration: BoxDecoration(
                    color: currentColor,
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: AppTheme.borderPrimary),
                  ),
                ),
                const SizedBox(width: 10),
                const Text(
                  'Özel Renk',
                  style: TextStyle(
                    color: AppTheme.textSecondary,
                    fontSize: 14,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTemplateSection() {
    final templates = [
      'Boş Sayfa',
      'Çizgili Kağıt', 
      'Kare Kağıt',
      'Noktalı Kağıt',
      'Müzik Kağıdı',
    ];

    return _buildSection(
      'Sayfa Şablonları',
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              color: AppTheme.bgCard,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppTheme.borderPrimary),
            ),
            child: DropdownButton<String>(
              value: currentTemplate,
              isExpanded: true,
              underline: const SizedBox(),
              dropdownColor: AppTheme.bgCard,
              style: const TextStyle(color: AppTheme.textPrimary),
              onChanged: (value) {
                if (value != null) onTemplateChanged(value);
              },
              items: templates.map((template) => DropdownMenuItem(
                value: template,
                child: Text(
                  template,
                  style: const TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 14,
                  ),
                ),
              )).toList(),
            ),
          ),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () {
                // TODO: Apply template
              },
              icon: const Icon(Icons.check, size: 16),
              label: const Text('Şablonu Uygula'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.accentColor,
                foregroundColor: AppTheme.textPrimary,
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSection(String title, {required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: AppTheme.borderPrimary,
            width: 1,
          ),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title.toUpperCase(),
            style: const TextStyle(
              color: AppTheme.textSecondary,
              fontSize: 13,
              fontWeight: FontWeight.w700,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 18),
          child,
        ],
      ),
    );
  }
}
