import 'package:flutter/material.dart';

import '../../../../core/theme/app_theme.dart';

class LayerData {
  final String id;
  String name;
  bool isVisible;
  bool isActive;

  LayerData({
    required this.id,
    required this.name,
    required this.isVisible,
    required this.isActive,
  });
}

class RightPanel extends StatefulWidget {
  final bool isStudyModeActive;
  final String currentTool;
  final String currentFont;
  final double currentFontSize;
  final Map<String, bool> textStyles;

  const RightPanel({
    super.key,
    required this.isStudyModeActive,
    required this.currentTool,
    required this.currentFont,
    required this.currentFontSize,
    required this.textStyles,
  });

  @override
  State<RightPanel> createState() => _RightPanelState();
}

class _RightPanelState extends State<RightPanel> {
  // Layer management
  List<LayerData> layers = [
    LayerData(id: '1', name: 'Katman 1', isVisible: true, isActive: true),
  ];

  // Study notes for each subject
  Map<String, String> subjectNotes = {
    'Matematik': '📚 DERS NOTLARI\n\n🔸 Konu: İntegral\n\n📝 Ana Kavramlar:\n• Belirsiz integral\n• Belirli integral\n\n💡 Önemli Formüller:\n• ∫ x^n dx = x^(n+1)/(n+1) + C\n\n❓ Sorular:\n• İntegral ile türev arasındaki ilişki nedir?\n\n🎯 Tekrar Edilecekler:\n• Substitüsyon yöntemi',
    'Fizik': '📚 DERS NOTLARI\n\n🔸 Konu: Newton Yasaları\n\n📝 Ana Kavramlar:\n• İvme\n• Kuvvet\n\n💡 Önemli Formüller:\n• F = m × a\n\n❓ Sorular:\n• Sürtünme kuvveti nasıl hesaplanır?\n\n🎯 Tekrar Edilecekler:\n• Dinamik denge',
    'Kimya': '📚 DERS NOTLARI\n\n🔸 Konu: Periyodik Tablo\n\n📝 Ana Kavramlar:\n• Elementler\n• Periyot ve gruplar\n\n💡 Önemli Formüller:\n• Atomik kütle hesabı\n\n❓ Sorular:\n• Elektron dizilimi nasıl yazılır?\n\n🎯 Tekrar Edilecekler:\n• Kimyasal bağlar',
    'Biyoloji': '📚 DERS NOTLARI\n\n🔸 Konu: Hücre Yapısı\n\n📝 Ana Kavramlar:\n• Mitokondri\n• Ribozom\n\n💡 Önemli Formüller:\n• ATP → ADP + P + Enerji\n\n❓ Sorular:\n• Protein sentezi nasıl gerçekleşir?\n\n🎯 Tekrar Edilecekler:\n• Enzim yapısı',
    'Tarih': '📚 DERS NOTLARI\n\n🔸 Konu: Osmanlı İmparatorluğu\n\n📝 Ana Kavramlar:\n• Devşirme sistemi\n• Tımar sistemi\n\n💡 Önemli Tarihler:\n• 1453 - İstanbul\'un fethi\n\n❓ Sorular:\n• Osmanlı hukuk sistemi nasıldı?\n\n🎯 Tekrar Edilecekler:\n• Yeniçeri teşkilatı',
  };

  String activeSubject = 'Matematik';
  late TextEditingController notesController;

  @override
  void initState() {
    super.initState();
    notesController = TextEditingController(text: subjectNotes[activeSubject] ?? '');
    
    // Auto-save functionality
    notesController.addListener(() {
      subjectNotes[activeSubject] = notesController.text;
    });
  }

  @override
  void dispose() {
    notesController.dispose();
    super.dispose();
  }

  void switchSubject(String subject) {
    setState(() {
      // Save current notes
      subjectNotes[activeSubject] = notesController.text;
      
      // Switch to new subject
      activeSubject = subject;
      notesController.text = subjectNotes[subject] ?? '';
    });
  }

  void addLayer() {
    setState(() {
      // Deactivate all layers
      for (var layer in layers) {
        layer.isActive = false;
      }
      
      // Add new layer
      layers.add(LayerData(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        name: 'Katman ${layers.length + 1}',
        isVisible: true,
        isActive: true,
      ));
    });
  }

  void selectLayer(LayerData layer) {
    setState(() {
      for (var l in layers) {
        l.isActive = l.id == layer.id;
      }
    });
  }

  void toggleLayerVisibility(LayerData layer) {
    setState(() {
      layer.isVisible = !layer.isVisible;
    });
  }

  void deleteLayer(LayerData layer) {
    if (layers.length <= 1) {
      // Show warning
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('En az bir katman bulunmalıdır!')),
      );
      return;
    }
    
    setState(() {
      layers.removeWhere((l) => l.id == layer.id);
      
      // If deleted layer was active, select first layer
      if (layer.isActive && layers.isNotEmpty) {
        layers.first.isActive = true;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 320,
      decoration: BoxDecoration(
        color: AppTheme.bgSecondary,
        border: Border(
          left: BorderSide(
            color: AppTheme.borderPrimary,
            width: 1,
          ),
        ),
      ),
      child: Column(
        children: [
          // Header
          Container(
            padding: const EdgeInsets.all(20),
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [AppTheme.primaryColor, AppTheme.primaryDarkColor],
              ),
            ),
            child: const Row(
              children: [
                Icon(Icons.school, color: AppTheme.textPrimary, size: 20),
                SizedBox(width: 10),
                Text(
                  'Ders Çalışma Merkezi',
                  style: TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          
          // Scrollable content
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(0),
              children: [
                if (widget.currentTool == 'text') _buildTextProperties(),
                _buildLayersSection(),
                _buildStudyNotes(),
                _buildSubjectTracker(),
                _buildFlashcards(),
                _buildStudyTimer(),
                _buildProjectInfo(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextProperties() {
    return _buildSection(
      'Metin Özellikleri',
      child: Column(
        children: [
          // Font family dropdown
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              color: AppTheme.bgCard,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppTheme.borderPrimary),
            ),
            child: DropdownButton<String>(
              value: widget.currentFont,
              isExpanded: true,
              underline: const SizedBox(),
              dropdownColor: AppTheme.bgCard,
              style: const TextStyle(color: AppTheme.textPrimary),
              onChanged: (value) {
                // TODO: Implement font change
              },
              items: ['Arial', 'Times New Roman', 'Georgia', 'Verdana']
                  .map((font) => DropdownMenuItem(
                        value: font,
                        child: Text(font),
                      ))
                  .toList(),
            ),
          ),
          
          const SizedBox(height: 10),
          
          // Font size slider
          Row(
            children: [
              Expanded(
                child: Slider(
                  value: widget.currentFontSize,
                  min: 12,
                  max: 72,
                  divisions: 60,
                  activeColor: AppTheme.primaryColor,
                  onChanged: (value) {
                    // TODO: Implement font size change
                  },
                ),
              ),
              Text(
                '${widget.currentFontSize.toInt()}px',
                style: const TextStyle(
                  color: AppTheme.textPrimary,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 10),
          
          // Text style buttons
          Row(
            children: [
              _buildTextStyleButton(Icons.format_bold, 'bold'),
              const SizedBox(width: 5),
              _buildTextStyleButton(Icons.format_italic, 'italic'),
              const SizedBox(width: 5),
              _buildTextStyleButton(Icons.format_underlined, 'underline'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTextStyleButton(IconData icon, String style) {
    final isActive = widget.textStyles[style] ?? false;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          // TODO: Toggle text style
        },
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: isActive ? AppTheme.primaryColor : AppTheme.bgCard,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: isActive ? AppTheme.primaryColor : AppTheme.borderPrimary,
              width: 2,
            ),
          ),
          child: Icon(
            icon,
            color: isActive ? AppTheme.textPrimary : AppTheme.textSecondary,
            size: 18,
          ),
        ),
      ),
    );
  }

  Widget _buildStudyNotes() {
    return _buildSection(
      'Ders Notları',
      child: Column(
        children: [
          // Subject tabs
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                'Matematik',
                'Fizik',
                'Kimya',
                'Biyoloji',
                'Tarih',
              ]
                  .map((subject) => Padding(
                        padding: const EdgeInsets.only(right: 4),
                        child: _buildSubjectTab(subject, subject == activeSubject),
                      ))
                  .toList(),
            ),
          ),
          
          const SizedBox(height: 15),
          
          // Notes text area
          Container(
            height: 200,
            padding: const EdgeInsets.all(15),
            decoration: BoxDecoration(
              color: AppTheme.bgCard,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppTheme.borderPrimary, width: 2),
            ),
            child: TextField(
              controller: notesController,
              maxLines: null,
              expands: true,
              style: const TextStyle(
                color: AppTheme.textPrimary,
                fontSize: 13,
                fontFamily: 'Fira Code',
              ),
              decoration: const InputDecoration(
                hintText: '📚 DERS NOTLARI\n\n🔸 Konu:\n\n📝 Ana Kavramlar:\n• \n• \n\n💡 Önemli Formüller:\n• \n\n❓ Sorular:\n• \n\n🎯 Tekrar Edilecekler:\n• ',
                hintStyle: TextStyle(color: AppTheme.textMuted),
                border: InputBorder.none,
              ),
            ),
          ),
          
          const SizedBox(height: 15),
          
          // Notes actions
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () {
                    // TODO: Save notes
                  },
                  icon: const Icon(Icons.bookmark, size: 16),
                  label: const Text('Kaydet'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.primaryColor,
                    foregroundColor: AppTheme.textPrimary,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () {
                    // TODO: Export notes
                  },
                  icon: const Icon(Icons.file_download, size: 16),
                  label: const Text('Dışa Aktar'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.bgCard,
                    foregroundColor: AppTheme.textSecondary,
                    side: const BorderSide(color: AppTheme.borderPrimary),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSubjectTab(String subject, bool isActive) {
    return GestureDetector(
      onTap: () => switchSubject(subject),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        decoration: BoxDecoration(
          color: isActive ? AppTheme.primaryColor : AppTheme.bgCard,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: isActive ? AppTheme.primaryColor : AppTheme.borderPrimary,
          ),
        ),
        child: Text(
          subject,
          style: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w500,
            color: isActive ? AppTheme.textPrimary : AppTheme.textSecondary,
          ),
        ),
      ),
    );
  }

  Widget _buildLayersSection() {
    return _buildSection(
      'Katmanlar',
      child: Column(
        children: [
          // Layers list
          Container(
            constraints: const BoxConstraints(maxHeight: 200),
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: layers.length,
              itemBuilder: (context, index) {
                final layer = layers[index];
                return Container(
                  margin: const EdgeInsets.only(bottom: 5),
                  decoration: BoxDecoration(
                    color: layer.isActive ? AppTheme.primaryColor : AppTheme.bgCard,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: layer.isActive ? AppTheme.primaryColor : AppTheme.borderPrimary,
                    ),
                  ),
                  child: ListTile(
                    dense: true,
                    leading: GestureDetector(
                      onTap: () => toggleLayerVisibility(layer),
                      child: Icon(
                        layer.isVisible ? Icons.visibility : Icons.visibility_off,
                        size: 20,
                        color: layer.isActive 
                            ? AppTheme.textPrimary 
                            : (layer.isVisible ? AppTheme.textSecondary : AppTheme.textMuted),
                      ),
                    ),
                    title: Text(
                      layer.name,
                      style: TextStyle(
                        color: layer.isActive ? AppTheme.textPrimary : AppTheme.textSecondary,
                        fontSize: 14,
                        fontWeight: layer.isActive ? FontWeight.w600 : FontWeight.normal,
                      ),
                    ),
                    trailing: layers.length > 1
                        ? GestureDetector(
                            onTap: () => deleteLayer(layer),
                            child: Icon(
                              Icons.close,
                              size: 16,
                              color: layer.isActive ? AppTheme.textPrimary : AppTheme.dangerColor,
                            ),
                          )
                        : null,
                    onTap: () => selectLayer(layer),
                  ),
                );
              },
            ),
          ),
          
          const SizedBox(height: 10),
          
          // Add layer button
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: addLayer,
              icon: const Icon(Icons.add, size: 16),
              label: const Text('Yeni Katman'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.accentColor,
                foregroundColor: AppTheme.textPrimary,
                padding: const EdgeInsets.symmetric(vertical: 8),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSubjectTracker() {
    final subjects = [
      {'name': 'Matematik', 'progress': 0.75},
      {'name': 'Fizik', 'progress': 0.60},
      {'name': 'Kimya', 'progress': 0.45},
    ];

    return _buildSection(
      'Ders İlerlemesi',
      child: Column(
        children: [
          ...subjects.map((subject) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: _buildSubjectProgressItem(
                  subject['name'] as String,
                  subject['progress'] as double,
                ),
              )),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () {
                // TODO: Add new subject
              },
              icon: const Icon(Icons.add, size: 16),
              label: const Text('Yeni Ders Ekle'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.secondaryColor,
                foregroundColor: AppTheme.textPrimary,
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSubjectProgressItem(String name, double progress) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.borderPrimary),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                name,
                style: const TextStyle(
                  color: AppTheme.textPrimary,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Text(
                '${(progress * 100).toInt()}%',
                style: const TextStyle(
                  color: AppTheme.accentColor,
                  fontWeight: FontWeight.w700,
                  fontSize: 14,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          LinearProgressIndicator(
            value: progress,
            backgroundColor: AppTheme.borderPrimary,
            valueColor: const AlwaysStoppedAnimation<Color>(AppTheme.accentColor),
            minHeight: 6,
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: _buildActionButton(Icons.add, 'Çalışma Ekle'),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _buildActionButton(Icons.quiz, 'Test Çöz'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildActionButton(IconData icon, String label) {
    return ElevatedButton.icon(
      onPressed: () {
        // TODO: Handle action
      },
      icon: Icon(icon, size: 12),
      label: Text(
        label,
        style: const TextStyle(fontSize: 10),
      ),
      style: ElevatedButton.styleFrom(
        backgroundColor: AppTheme.bgTertiary,
        foregroundColor: AppTheme.textSecondary,
        padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
        minimumSize: const Size(0, 30),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
          side: const BorderSide(color: AppTheme.borderSecondary),
        ),
      ),
    );
  }

  Widget _buildFlashcards() {
    return _buildSection(
      'Flash Kartlar',
      child: Column(
        children: [
          // Flashcard
          Container(
            height: 120,
            decoration: BoxDecoration(
              color: AppTheme.bgCard,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppTheme.borderPrimary, width: 2),
            ),
            child: const Center(
              child: Padding(
                padding: EdgeInsets.all(15),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'İntegral Nedir?',
                      style: TextStyle(
                        color: AppTheme.textPrimary,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                      textAlign: TextAlign.center,
                    ),
                    SizedBox(height: 8),
                    Text(
                      'Matematik - Analiz',
                      style: TextStyle(
                        color: AppTheme.textSecondary,
                        fontSize: 13,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          
          const SizedBox(height: 15),
          
          // Controls
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () {},
                  icon: const Icon(Icons.flip_to_back, size: 16),
                  label: const Text('Çevir'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.bgCard,
                    foregroundColor: AppTheme.textSecondary,
                    side: const BorderSide(color: AppTheme.borderPrimary),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () {},
                  icon: const Icon(Icons.check, size: 16),
                  label: const Text('Kolay'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.accentColor,
                    foregroundColor: AppTheme.textPrimary,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () {},
                  icon: const Icon(Icons.close, size: 16),
                  label: const Text('Zor'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.dangerColor,
                    foregroundColor: AppTheme.textPrimary,
                  ),
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 10),
          
          // Stats
          const Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Kart 1/15',
                style: TextStyle(
                  color: AppTheme.textMuted,
                  fontSize: 12,
                ),
              ),
              Text(
                '•',
                style: TextStyle(color: AppTheme.textMuted),
              ),
              Text(
                'Doğru: 12',
                style: TextStyle(
                  color: AppTheme.textMuted,
                  fontSize: 12,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStudyTimer() {
    return _buildSection(
      'Çalışma Zamanlayıcı',
      child: Column(
        children: [
          // Timer circle
          SizedBox(
            width: 80,
            height: 80,
            child: Stack(
              children: [
                // Progress circle
                SizedBox(
                  width: 80,
                  height: 80,
                  child: CircularProgressIndicator(
                    value: 0.75,
                    strokeWidth: 3,
                    backgroundColor: AppTheme.borderPrimary,
                    valueColor: const AlwaysStoppedAnimation<Color>(AppTheme.primaryColor),
                  ),
                ),
                // Time display
                const Center(
                  child: Text(
                    '25:00',
                    style: TextStyle(
                      color: AppTheme.textPrimary,
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
          ),
          
          const SizedBox(height: 15),
          
          // Timer controls
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _buildTimerButton(Icons.play_arrow, () {}),
              const SizedBox(width: 8),
              _buildTimerButton(Icons.stop, () {}),
            ],
          ),
          
          const SizedBox(height: 15),
          
          // Stats
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildStatItem('Bugün', '0dk'),
              _buildStatItem('Seri', '0g'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTimerButton(IconData icon, VoidCallback onPressed) {
    return Container(
      width: 40,
      height: 40,
      decoration: BoxDecoration(
        color: AppTheme.bgCard,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppTheme.borderPrimary, width: 2),
      ),
      child: IconButton(
        onPressed: onPressed,
        icon: Icon(
          icon,
          size: 18,
          color: AppTheme.textSecondary,
        ),
        padding: EdgeInsets.zero,
      ),
    );
  }

  Widget _buildStatItem(String label, String value) {
    return Column(
      children: [
        Text(
          label,
          style: const TextStyle(
            color: AppTheme.textMuted,
            fontSize: 11,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(
            color: AppTheme.textPrimary,
            fontSize: 16,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }

  Widget _buildProjectInfo() {
    return _buildSection(
      'Proje Bilgileri',
      child: Column(
        children: [
          _buildInfoItem('Proje Adı:', 'Çizimim'),
          _buildInfoItem('Canvas Boyutu:', '800 x 600 px'),
          _buildInfoItem('Oluşturulma:', 'Bugün'),
          
          const SizedBox(height: 15),
          
          // Export options
          const Text(
            'DIŞA AKTARMA',
            style: TextStyle(
              color: AppTheme.textSecondary,
              fontSize: 11,
              fontWeight: FontWeight.w700,
              letterSpacing: 1,
            ),
          ),
          
          const SizedBox(height: 10),
          
          GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 2,
            crossAxisSpacing: 8,
            mainAxisSpacing: 8,
            childAspectRatio: 2,
            children: [
              _buildExportButton('PNG', Icons.image),
              _buildExportButton('JPG', Icons.photo),
              _buildExportButton('PDF', Icons.picture_as_pdf),
              _buildExportButton('SVG', Icons.code),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildInfoItem(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: AppTheme.textSecondary,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
          Text(
            value,
            style: const TextStyle(
              color: AppTheme.textPrimary,
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildExportButton(String format, IconData icon) {
    return ElevatedButton(
      onPressed: () {
        // TODO: Export as format
      },
      style: ElevatedButton.styleFrom(
        backgroundColor: AppTheme.bgCard,
        foregroundColor: AppTheme.textSecondary,
        side: const BorderSide(color: AppTheme.borderPrimary),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 16),
          const SizedBox(height: 2),
          Text(
            format,
            style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }

  Widget _buildSection(String title, {required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: AppTheme.borderPrimary,
            width: 1,
          ),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title.toUpperCase(),
            style: const TextStyle(
              color: AppTheme.textSecondary,
              fontSize: 13,
              fontWeight: FontWeight.w700,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 18),
          child,
        ],
      ),
    );
  }
}
