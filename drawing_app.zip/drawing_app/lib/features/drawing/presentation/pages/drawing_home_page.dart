import 'package:flutter/material.dart';

import '../../../../core/theme/app_theme.dart';
import '../widgets/app_header.dart';
import '../widgets/left_panel.dart';
import '../widgets/canvas_panel.dart';
import '../widgets/right_panel.dart';

class DrawingHomePage extends StatefulWidget {
  const DrawingHomePage({super.key});

  @override
  State<DrawingHomePage> createState() => _DrawingHomePageState();
}

class _DrawingHomePageState extends State<DrawingHomePage> {
  // Drawing state
  String currentTool = 'pen';
  Color currentColor = Colors.black;
  double currentSize = 5.0;
  String currentTemplate = 'blank';
  bool isStudyModeActive = false;

  // Text properties
  String currentFont = 'Arial';
  double currentFontSize = 16.0;
  Map<String, bool> textStyles = {
    'bold': false,
    'italic': false,
    'underline': false,
  };

  void updateTool(String tool) {
    setState(() {
      currentTool = tool;
    });
  }

  void updateColor(Color color) {
    setState(() {
      currentColor = color;
    });
  }

  void updateSize(double size) {
    setState(() {
      currentSize = size;
    });
  }

  void toggleStudyMode() {
    setState(() {
      isStudyModeActive = !isStudyModeActive;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.bgPrimary,
      body: Column(
        children: [
          // Header
          AppHeader(
            currentTool: currentTool,
            currentSize: currentSize,
            currentColor: currentColor,
            isStudyModeActive: isStudyModeActive,
            onToggleStudyMode: toggleStudyMode,
            onSaveProject: () {
              // TODO: Implement save project
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Proje kaydedildi!')),
              );
            },
          ),
          
          // Main content
          Expanded(
            child: Row(
              children: [
                // Left Panel - Drawing Tools
                LeftPanel(
                  currentTool: currentTool,
                  currentColor: currentColor,
                  currentSize: currentSize,
                  currentTemplate: currentTemplate,
                  currentFont: currentFont,
                  currentFontSize: currentFontSize,
                  textStyles: textStyles,
                  onToolChanged: updateTool,
                  onColorChanged: updateColor,
                  onSizeChanged: updateSize,
                  onTemplateChanged: (template) {
                    setState(() {
                      currentTemplate = template;
                    });
                  },
                  onFontChanged: (font) {
                    setState(() {
                      currentFont = font;
                    });
                  },
                  onFontSizeChanged: (size) {
                    setState(() {
                      currentFontSize = size;
                    });
                  },
                  onTextStyleChanged: (style, value) {
                    setState(() {
                      textStyles[style] = value;
                    });
                  },
                ),
                
                // Center Panel - Canvas
                Expanded(
                  child: CanvasPanel(
                    currentTool: currentTool,
                    currentColor: currentColor,
                    currentSize: currentSize,
                    currentTemplate: currentTemplate,
                  ),
                ),
                
                // Right Panel - Study Features
                RightPanel(
                  isStudyModeActive: isStudyModeActive,
                  currentTool: currentTool,
                  currentFont: currentFont,
                  currentFontSize: currentFontSize,
                  textStyles: textStyles,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
