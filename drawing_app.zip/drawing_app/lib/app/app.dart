import 'package:flutter/material.dart';

import '../core/theme/app_theme.dart';
import '../features/splash/presentation/pages/splash_page.dart';
import '../features/drawing/presentation/pages/drawing_home_page.dart';

class StudyDrawApp extends StatelessWidget {
  const StudyDrawApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'StudyDraw - Akıllı Ders Çalışma & Çizim Uygulaması',
      debugShowCheckedModeBanner: false,
      
      // Tema
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: ThemeMode.dark, // Orijinal uygulamada dark theme kullanılıyor
      
      // Ana sayfa
      home: const SplashPage(),
      
      // Routes tanımları
      routes: {
        '/home': (context) => const DrawingHomePage(),
      },
    );
  }
}
